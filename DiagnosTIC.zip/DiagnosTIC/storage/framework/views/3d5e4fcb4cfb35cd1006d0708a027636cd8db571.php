<style>
    .img_bienvenido{
        width: 1000px;
        height: 500px;
        display:block;
        margin:auto; 
  }
</style>
<?php $__env->startSection('content'); ?>
<div>
    <h1 class="tittle">Bienvenidos a Diagnostic</h1>
    <img src="<?php echo e(URL::asset('img/imagenbienvenido.jpg')); ?>" class="img_bienvenido">
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/usuario/Documents/DiagnosTIC/resources/views/home.blade.php ENDPATH**/ ?>