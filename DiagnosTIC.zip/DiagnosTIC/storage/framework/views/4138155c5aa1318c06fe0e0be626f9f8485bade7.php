<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('pacienteid')); ?>

            <!-- <?php echo e(Form::text('pacienteid', $antecedente->pacienteid, ['class' => 'form-control' . ($errors->has('pacienteid') ? ' is-invalid' : ''), 'placeholder' => 'Pacienteid'])); ?> -->
            <select name="pacienteid" id="pacienteid" class="form-control"></select>
            <?php echo $errors->first('pacienteid', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('peso')); ?>

            <?php echo e(Form::text('peso', $antecedente->peso, ['class' => 'form-control' . ($errors->has('peso') ? ' is-invalid' : ''), 'placeholder' => 'Peso'])); ?>

            <?php echo $errors->first('peso', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('estatura')); ?>

            <?php echo e(Form::text('estatura', $antecedente->estatura, ['class' => 'form-control' . ($errors->has('estatura') ? ' is-invalid' : ''), 'placeholder' => 'Estatura'])); ?>

            <?php echo $errors->first('estatura', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('presion')); ?>

            <?php echo e(Form::text('presion', $antecedente->presion, ['class' => 'form-control' . ($errors->has('presion') ? ' is-invalid' : ''), 'placeholder' => 'Presion'])); ?>

            <?php echo $errors->first('presion', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('enfermedad_actuales')); ?>

            <?php echo e(Form::text('enfermedad_actuales', $antecedente->enfermedad_actuales, ['class' => 'form-control' . ($errors->has('enfermedad_actuales') ? ' is-invalid' : ''), 'placeholder' => 'Enfermedad Actuales'])); ?>

            <?php echo $errors->first('enfermedad_actuales', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('medicamentos')); ?>

            <?php echo e(Form::text('medicamentos', $antecedente->medicamentos, ['class' => 'form-control' . ($errors->has('medicamentos') ? ' is-invalid' : ''), 'placeholder' => 'Medicamentos'])); ?>

            <?php echo $errors->first('medicamentos', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('alergias')); ?>

            <?php echo e(Form::text('alergias', $antecedente->alergias, ['class' => 'form-control' . ($errors->has('alergias') ? ' is-invalid' : ''), 'placeholder' => 'Alergias'])); ?>

            <?php echo $errors->first('alergias', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('intervenciones_quirurgicas')); ?>

            <?php echo e(Form::text('intervenciones_quirurgicas', $antecedente->intervenciones_quirurgicas, ['class' => 'form-control' . ($errors->has('intervenciones_quirurgicas') ? ' is-invalid' : ''), 'placeholder' => 'Intervenciones Quirurgicas'])); ?>

            <?php echo $errors->first('intervenciones_quirurgicas', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('transfuciones')); ?>

            <?php echo e(Form::text('transfuciones', $antecedente->transfuciones, ['class' => 'form-control' . ($errors->has('transfuciones') ? ' is-invalid' : ''), 'placeholder' => 'Transfuciones'])); ?>

            <?php echo $errors->first('transfuciones', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('antecedentes_familiares')); ?>

            <?php echo e(Form::text('antecedentes_familiares', $antecedente->antecedentes_familiares, ['class' => 'form-control' . ($errors->has('antecedentes_familiares') ? ' is-invalid' : ''), 'placeholder' => 'Antecedentes Familiares'])); ?>

            <?php echo $errors->first('antecedentes_familiares', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div><?php /**PATH /Users/usuario/Documents/DiagnosTIC/resources/views/antecedente/form.blade.php ENDPATH**/ ?>