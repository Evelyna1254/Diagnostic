<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('nombres')); ?>

            <?php echo e(Form::text('nombres', $persona->nombres, ['class' => 'form-control' . ($errors->has('nombres') ? ' is-invalid' : ''), 'placeholder' => 'Nombres'])); ?>

            <?php echo $errors->first('nombres', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('apellidos')); ?>

            <?php echo e(Form::text('apellidos', $persona->apellidos, ['class' => 'form-control' . ($errors->has('apellidos') ? ' is-invalid' : ''), 'placeholder' => 'Apellidos'])); ?>

            <?php echo $errors->first('apellidos', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('identificacion')); ?>

            <?php echo e(Form::text('identificacion', $persona->identificacion, ['class' => 'form-control' . ($errors->has('identificacion') ? ' is-invalid' : ''), 'placeholder' => 'Identificacion'])); ?>

            <?php echo $errors->first('identificacion', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('fecha_nacimiento')); ?>

            <?php echo e(Form::text('fecha_nacimiento', $persona->fecha_nacimiento, ['class' => 'form-control' . ($errors->has('fecha_nacimiento') ? ' is-invalid' : ''), 'placeholder' => 'Fecha Nacimiento'])); ?>

            <?php echo $errors->first('fecha_nacimiento', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group" style="display: none;">
            <?php echo e(Form::label('tipo_persona')); ?>

            <?php echo e(Form::text('tipo_persona', $persona->tipo_persona, ['class' => 'form-control' . ($errors->has('tipo_persona') ? ' is-invalid' : ''), 'placeholder' => 'Tipo Persona'])); ?>

            <?php echo $errors->first('tipo_persona', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('telefono')); ?>

            <?php echo e(Form::text('telefono', $persona->telefono, ['class' => 'form-control' . ($errors->has('telefono') ? ' is-invalid' : ''), 'placeholder' => 'Telefono'])); ?>

            <?php echo $errors->first('telefono', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('correo_electronico')); ?>

            <?php echo e(Form::text('correo_electronico', $persona->correo_electronico, ['class' => 'form-control' . ($errors->has('correo_electronico') ? ' is-invalid' : ''), 'placeholder' => 'Correo Electronico'])); ?>

            <?php echo $errors->first('correo_electronico', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Rh')); ?>

            <?php echo e(Form::text('Rh', $persona->Rh, ['class' => 'form-control' . ($errors->has('Rh') ? ' is-invalid' : ''), 'placeholder' => 'Rh'])); ?>

            <?php echo $errors->first('Rh', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('genero')); ?>

            <?php echo e(Form::text('genero', $persona->genero, ['class' => 'form-control' . ($errors->has('genero') ? ' is-invalid' : ''), 'placeholder' => 'Género'])); ?>

            <?php echo $errors->first('genero', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div><?php /**PATH /Users/usuario/Documents/DiagnosTIC/resources/views/persona/form.blade.php ENDPATH**/ ?>