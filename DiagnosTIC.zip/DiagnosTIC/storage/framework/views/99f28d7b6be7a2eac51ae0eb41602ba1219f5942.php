<?php $__env->startSection('template_title'); ?>
    <?php echo e($persona->name ?? 'Show Persona'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Persona</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('persona.index')); ?>"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Nombres:</strong>
                            <?php echo e($persona->nombres); ?>

                        </div>
                        <div class="form-group">
                            <strong>Apellidos:</strong>
                            <?php echo e($persona->apellidos); ?>

                        </div>
                        <div class="form-group">
                            <strong>Identificacion:</strong>
                            <?php echo e($persona->identificacion); ?>

                        </div>
                        <div class="form-group">
                            <strong>Fecha Nacimiento:</strong>
                            <?php echo e($persona->fecha_nacimiento); ?>

                        </div>
                        <div class="form-group">
                            <strong>Tipo Persona:</strong>
                            <?php echo e($persona->tipo_persona); ?>

                        </div>
                        <div class="form-group">
                            <strong>Telefono:</strong>
                            <?php echo e($persona->telefono); ?>

                        </div>
                        <div class="form-group">
                            <strong>Correo Electronico:</strong>
                            <?php echo e($persona->correo_electronico); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/usuario/Documents/DiagnosTIC/resources/views/persona/show.blade.php ENDPATH**/ ?>