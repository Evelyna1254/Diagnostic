<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('agendaid')); ?>

            <select name="agendaid" id="agendaid" class="form-control"></select>
            <!-- <?php echo e(Form::text('agendaid', $consulta->agendaid, ['class' => 'form-control' . ($errors->has('agendaid') ? ' is-invalid' : ''), 'placeholder' => 'Agendaid'])); ?> -->
            <?php echo $errors->first('agendaid', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('antecedenteid')); ?>

            <select name="antecedenteid" id="antecedenteid" class="form-control"></select>
            <!-- <?php echo e(Form::text('antecedenteid', $consulta->antecedenteid, ['class' => 'form-control' . ($errors->has('antecedenteid') ? ' is-invalid' : ''), 'placeholder' => 'Antecedenteid'])); ?> -->
            <?php echo $errors->first('antecedenteid', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('profesionalid')); ?>

            <select name="profesionalid" id="profesionalid" class="form-control"></select>
            <!-- <?php echo e(Form::text('profesionalid', $consulta->profesionalid, ['class' => 'form-control' . ($errors->has('profesionalid') ? ' is-invalid' : ''), 'placeholder' => 'Profesionalid'])); ?> -->
            <?php echo $errors->first('profesionalid', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('diagnostico')); ?>

            <?php echo e(Form::text('diagnostico', $consulta->diagnostico, ['class' => 'form-control' . ($errors->has('diagnostico') ? ' is-invalid' : ''), 'placeholder' => 'Diagnostico'])); ?>

            <?php echo $errors->first('diagnostico', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('observaciones')); ?>

            <?php echo e(Form::text('observaciones', $consulta->observaciones, ['class' => 'form-control' . ($errors->has('observaciones') ? ' is-invalid' : ''), 'placeholder' => 'Observaciones'])); ?>

            <?php echo $errors->first('observaciones', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div><?php /**PATH /Users/usuario/Documents/DiagnosTIC/resources/views/consulta/form.blade.php ENDPATH**/ ?>