<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('descripcion_cita')); ?>

            <?php echo e(Form::text('descripcion_cita', $agenda->descripcion_cita, ['class' => 'form-control' . ($errors->has('descripcion_cita') ? ' is-invalid' : ''), 'placeholder' => 'Descripcion Cita'])); ?>

            <?php echo $errors->first('descripcion_cita', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('fecha')); ?>

            <?php echo e(Form::text('fecha', $agenda->fecha, ['class' => 'form-control' . ($errors->has('fecha') ? ' is-invalid' : ''), 'placeholder' => 'Fecha'])); ?>

            <?php echo $errors->first('fecha', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('hora_inicio')); ?>

            <?php echo e(Form::text('hora_inicio', $agenda->hora_inicio, ['class' => 'form-control' . ($errors->has('hora_inicio') ? ' is-invalid' : ''), 'placeholder' => 'Hora Inicio'])); ?>

            <?php echo $errors->first('hora_inicio', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('hora_fin')); ?>

            <?php echo e(Form::text('hora_fin', $agenda->hora_fin, ['class' => 'form-control' . ($errors->has('hora_fin') ? ' is-invalid' : ''), 'placeholder' => 'Hora Fin'])); ?>

            <?php echo $errors->first('hora_fin', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div><?php /**PATH C:\Proyectos\DiagnosTIC\resources\views/agenda/form.blade.php ENDPATH**/ ?>