<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('profesionalid')); ?>

            <!-- <?php echo e(Form::text('profesionalid', $receta->profesionalid, ['class' => 'form-control' . ($errors->has('profesionalid') ? ' is-invalid' : ''), 'placeholder' => 'Profesionalid'])); ?> -->
            <select name="profesionalid" id="profesionalid" class="form-control" value="<?php echo e($receta->profesionalid); ?>"></select>
            <?php echo $errors->first('profesionalid', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('pacienteid')); ?>

            <!-- <?php echo e(Form::text('pacienteid', $receta->pacienteid, ['class' => 'form-control' . ($errors->has('pacienteid') ? ' is-invalid' : ''), 'placeholder' => 'Pacienteid'])); ?> -->
            <select name="pacienteid" id="pacienteid" class="form-control"></select>
            <?php echo $errors->first('pacienteid', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('medicamento')); ?>

            <?php echo e(Form::text('medicamento', $receta->medicamento, ['class' => 'form-control' . ($errors->has('medicamento') ? ' is-invalid' : ''), 'placeholder' => 'Medicamento'])); ?>

            <?php echo $errors->first('medicamento', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('pautas')); ?>

            <?php echo e(Form::text('pautas', $receta->pautas, ['class' => 'form-control' . ($errors->has('pautas') ? ' is-invalid' : ''), 'placeholder' => 'Pautas'])); ?>

            <?php echo $errors->first('pautas', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('fecha')); ?>

            <?php echo e(Form::text('fecha', $receta->fecha, ['class' => 'form-control' . ($errors->has('fecha') ? ' is-invalid' : ''), 'placeholder' => 'Fecha'])); ?>

            <?php echo $errors->first('fecha', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div><?php /**PATH /Users/usuario/Documents/DiagnosTIC/resources/views/receta/form.blade.php ENDPATH**/ ?>